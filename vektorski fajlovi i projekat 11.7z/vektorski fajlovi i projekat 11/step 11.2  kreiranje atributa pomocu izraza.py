lejer = QgsVectorLayer('Polygon?crs=epsg:32634', 'Škola', 'memory')
pr = lejer.dataProvider()
pr.addAttributes(
[QgsField('ime', QVariant.String),
QgsField('br ucenika', QVariant.Int),
QgsField('povrsina', QVariant.Int)]
)

podaci = [
{'ime': 'Hemijsko-prehrambena tehnološka škola', 'br ucenika': 900, 'povrsina': 8055.4},
{'ime': 'XIII beogradska gimnazija', 'br ucenika': 1200, 'povrsina': 1685.80},
{'ime': 'OŠ Josip Pančić', 'br ucenika': 490, 'povrsina': 5931.2}

]

for podatak in podaci:
    f = QgsFeature()
    f.setAttributes([podatak['ime'], podatak['br ucenika'], podatak['povrsina']])
    pr.addFeature(f)

lejer.updateExtents()
QgsProject.instance().addMapLayer(lejer)

# prvi izraz racuna ukupan broj stanovnika
# drugi izraz kreira bafer zonu oko tacaka, na osnovu 
# nadmorske visine a zatim racuna povrsinu te bafer zone
izraz1 = QgsExpression('sum("br ucenika")')
izraz2 = QgsExpression('area($geometry, "povrsina"))')


# QgsExpressionContextUtils.globalProjectLayerScopes() je funkcija koja nam pomaze
# da dodamo globalni obim (scope), projekat, i lejere (unutar tog obima) u isto vreme
# Alternativno, oni se mogu rucno dodavati. Vazno zapamtiti, uvek se krece od najopstijeg
# do najspecificnijeg obimu (npr. od gobalnog, ka projektu, ka lejerima)
# vise o obimu na https://realpython.com/python-namespaces-scope/
context = QgsExpressionContext()
context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(lejer))

with edit(lejer):
    for f in lejer.getFeatures():
        context.setFeature(f)
        f['br ucenika'] = izraz1.evaluate(context)
        lejer.updateFeature(f)

print(f['br ucenika'])

print('------------------------------')

# Prilikom izvrsavanja izraz ili njegovog rascljanjivanja
# moze doci do gresaka, pa je korisno isprobati i videti da li je sve u redu
# ukoliko nije, Pajton ce u ovom slucaju prijaviti da postoji greska
#izraz = QgsExpression('1+1=2')
#if exp.hasParserError():
    #raise Exception(exp.parserErrorString())

#vrednost = exp.evaluate()
#if vrednost.hasEvalError():
    #raise ValueError(exp.evalErrorString())