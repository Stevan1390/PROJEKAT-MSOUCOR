# 6.3. Selecting features
#In QGIS desktop, features can be selected in different ways: 
#the user can click on a feature, draw a rectangle on the map canvas or use an expression filter. 
#Selected features are normally highlighted in a different color (default is yellow) to draw user’s attention on the selection.
# Sometimes it can be useful to programmatically select features or to change the default color.

import os # Ovo je potrebno i u  pyqgis konzoli

#To select all the features,
# Get the active layer (must be a vector layer)
layer = iface.activeLayer()
layer.selectAll()

#To select using an expression
# Assumes that the active layer is points.shp file from the QGIS test suite
# (Class (string) and Heading (number) are attributes in points.shp)
layer = iface.activeLayer()
layer.selectByExpression('"Class"=\'B52\' and "Heading" > 10 and "Heading" <70', QgsVectorLayer.SetSelection)

#To change the selection color you can use
iface.mapCanvas().setSelectionColor( QColor("purple") )
# Get the active layer (must be a vector layer)
layer = iface.activeLayer()
layer.selectAll()

#To add features to the selected features list for a given layer,
selected_fid = []

# Get the first feature id from the layer
for feature in layer.getFeatures():
    selected_fid.append(feature.id())
    break

# Add these features to the selected list
layer.select(selected_fid)