# korisceni unutar 250m objekti
lejer = iface.activeLayer()

renderer = lejer.renderer()

print('Tip: ', renderer.type())
print(renderer.dump())

# menja simbol lejera
simbol = QgsMarkerSymbol.createSimple({'name': 'triangle', 'color': 'lightgreen'})
renderer.setSymbol(simbol)
lejer.triggerRepaint()

# ukoliko zelimo da vidimo sve osobenosti 
# prvog simbol lejera koji smo kreirali 
print(renderer.symbol().symbolLayers()[0].properties())

# menja velicinu simbola
renderer.symbol().symbolLayer(0).setSize(3)
# nekim osobenostima nije moguce pristupiti pomocu metoda,
# vec se moze zameniti simbol u potpunosti
props = lejer.renderer().symbol().symbolLayer(0).properties()
props['name'] = 'square'
props['color'] = 'lightgreen'
renderer.setSymbol(QgsMarkerSymbol.createSimple(props))
# prikazuje promene
lejer.triggerRepaint()
lejer = iface.activeLayer()

kategorizovani_renderer = QgsCategorizedSymbolRenderer()
# Dodaje par kategorija
kat1 = QgsRendererCategory('1', QgsMarkerSymbol(), 'kategorija 1')
kat2 = QgsRendererCategory('2', QgsMarkerSymbol(), 'kategorija 2')
kat3 = QgsRendererCategory('3', QgsMarkerSymbol(), 'kategorija 3')

# kreiranje simbola za svaku kategoriju
simbol_1 = QgsMarkerSymbol.createSimple({'name': 'diamond', 'color': 'blue'})
kat1.setSymbol(simbol_1)

simbol_2 = QgsMarkerSymbol.createSimple({'name': 'square', 'color': 'yellow'})
kat2.setSymbol(simbol_2)

simbol_3 = QgsMarkerSymbol.createSimple({'name': 'triangle', 'color': 'orange'})
kat3.setSymbol(simbol_3)

# dodavanje kategorija rendereru
kategorizovani_renderer.addCategory(kat1)
kategorizovani_renderer.addCategory(kat2)
kategorizovani_renderer.addCategory(kat3)

for kat in kategorizovani_renderer.categories():
    print('{}: {} :: {}'.format(kat.value(), kat.label(), kat.symbol()))

kategorizovani_renderer.setClassAttribute('kategorije')
lejer.setRenderer(kategorizovani_renderer)
lejer.triggerRepaint()