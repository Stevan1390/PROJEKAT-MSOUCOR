# kreiranje geometrije iz koordinata, podesiti odgovarajuću projekciju u metrima
gTacka = QgsGeometry.fromPointXY(QgsPointXY(390905,4842421))
print(gTacka)
gLinija = QgsGeometry.fromPolyline([QgsPoint(390905,4842421), QgsPoint(398628,4836628)])
print(gLinija)
gPoligon = QgsGeometry.fromPolygonXY([
[QgsPointXY(400559,4836869), 
QgsPointXY(404180,4834214),
QgsPointXY(397904,483566)]
])
print(gLinija)