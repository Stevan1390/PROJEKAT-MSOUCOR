root = QgsProject.instance().layerTreeRoot()
Skola = QgsProject.instance().mapLayersByName("Škola")[0]


# pomeranje lejera u legendi
# kreiranje objekta QgsLayerTreeLayer iz Škola po njegovom ID-u
zpdvektor = root.findLayer(Škola.id())
# klonira se prethodno kreirani objekat
Školavektorklon = Školavektor.clone()
# uzima "roditelja". Ukoliko je rezultat None,
# znaci da lejer nije ni u jednog grupi i vratice ''
roditelj = Školavektor.parent()
# pomera se klonirani lejer na vrh
roditelj.insertChildNode(0, Školavektorklon)
# uklanja se originalni lejer (Školavektor)
root.removeChildNode(Školavektor)

# prebacivanje lejera u odredjenu grupu (slican postupak kao kod pomeranja)
Školavektor = root.findLayer(Škola.id())
Školavektorklon = Školavektor.clone()
# kreiranje nove grupe
grupa1 = root.addGroup('Grupa')
roditelj = Školavektor.parent()
grupa1.insertChildNode(0, Školavektorklon)
roditelj.removeChildNode(Školavektor)










