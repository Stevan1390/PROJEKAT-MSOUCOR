# Ukoliko se skripta pokrece izvan QGIS-a, potrebno je importovati
# qgis i PyQT klase koje ce se koristiti
# from qgis.core import QgisProject

# Instanciranje projekta
project = QgsProject.instance()

# Ucitavanje projekta
project.read ("/Users/Stevan/Documents/vektorski fajlovi i projekat 11/rad.qgz")

# Ukoliko menjamo nesto u projektu, uvek mozemo da to da sacuvamo pod istim imenom
project.write()
# Ili pod razlicitim
project.write ("E:/Fakultet/programiranje_ispit/Podaci_qgis/rad_newwork")

# Menja lose "putanje", u slucaju da doslo do promene lokacije lejera, promene adrese od hosta baze podataka...
'''def my_processor(path):
    return path.replace('host=10.1.1.115', 'host=10.1.1.116')

QgsPathResolver.setPathPreprocessor(my_processor)'''

