# korisceni lejer: unutar 250m objekti
lejer = iface.activeLayer()

renderer = lejer.renderer()

print('Tip: ', renderer.type())
print(renderer.dump())

# menja simbol lejera
simbol = QgsMarkerSymbol.createSimple({'name': 'triangle', 'color': 'lightgreen'})
renderer.setSymbol(simbol)
lejer.triggerRepaint()

# ukoliko zelimo da vidimo sve osobenosti 
# prvog simbol lejera koji smo kreirali 
print(renderer.symbol().symbolLayers()[0].properties())

# menja velicinu simbola
renderer.symbol().symbolLayer(0).setSize(3)
# nekim osobenostima nije moguce pristupiti pomocu metoda,
# vec se moze zameniti simbol u potpunosti
props = lejer.renderer().symbol().symbolLayer(0).properties()
props['name'] = 'square'
props['color'] = 'lightgreen'
renderer.setSymbol(QgsMarkerSymbol.createSimple(props))
# prikazuje promene
lejer.triggerRepaint()