import os
path_to_B_1 ="/Users/Stevan/Documents/vektorski fajlovi i projekat 11/B_1.tif"
rlayer = QgsRasterLayer(path_to_B_1, "B_1.tif")
if not rlayer.isValid():
    print("Layer ne moze da se ucita!")
