# korisceni lejer = Geologija Cajetina

lejer = QgsProject.instance().mapLayersByName('')[0]
# moze i preko iface.activeLayer()

# filtrira zasticena podrucja kojima skracenica pocinje sa 'H',
# zatim izvlaci njihove feature-e
upit = '"OpisKart_1" LIKE \'H%\''
features = lejer.getFeatures(QgsFeatureRequest().setFilterExpression(upit))

# vrsi iteraciju nad feature-ima, i izvrsava 
# geometrijsku komputaciju i stampa rezultate
for f in features:
    geom = f.geometry()
    naziv = f.attribute('OpisStari')
    print(naziv)
    print('Povrsina (km_2): ', geom.area()/1000000)
    print('Duzina (km): ', geom.length()/1000)
    
print('-----------------------------------------')