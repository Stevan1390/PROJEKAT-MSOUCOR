path_to_unutar_250m_objekti_layer = "/Users/Stevan/Documents/vektorski fajlovi i projekat 11/unutar 250m objekti.shp"


vlayer = QgsVectorLayer(path_to_unutar_250m_objekti_layer, "unutar 250m objekti", "ogr")
if not vlayer.isValid():
    print("Layer ne moze da se ucita!")
else:
    QgsProject.instance().addMapLayer(vlayer)
for field in vlayer.fields():
    print(field.name(), field.typeName())

print(vlayer.displayField())