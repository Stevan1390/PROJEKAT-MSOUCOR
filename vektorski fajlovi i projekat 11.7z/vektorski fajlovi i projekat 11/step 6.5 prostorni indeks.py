import os 
path_to_Emiter_layer = "/Users/Stevan/Documents/vektorski fajlovi i projekat/Emiter.shp"


vlayer = QgsVectorLayer(path_to_Emiter_layer, "Emiter", "ogr")
if not vlayer.isValid():
    print("Layer nije ucitan!")
else:
    QgsProject.instance().addMapLayer(vlayer)
#To select all the features,
# Get the active layer (must be a vector layer)
layer = iface.activeLayer()
layer.selectAll()

#To select using an expression
# Assumes that the active layer is points.shp file from the QGIS test suite
# (boja (string) and visina (number) are attributes in points.shp)
layer = iface.activeLayer()
layer.selectByExpression('"boja"=\'crvena\' and "visina" > 10 and "visina" <70', QgsVectorLayer.SetSelection)

#za promenu boje datog vektora (point.shp)
iface.mapCanvas().setSelectionColor( QColor("purple") )
# Get the active layer (must be a vector layer)
layer = iface.activeLayer()
layer.selectAll()

#To add features to the selected features list for a given layer,
selected_fid = []

# Get the first feature id from the layer
for feature in layer.getFeatures():
    selected_fid.append(feature.id())
    break

# Add these features to the selected list
layer.select(selected_fid)
#To clear the selection:
layer.removeSelection()

#6.3.1. Accessing attributes
#Attributes can be referred to by their name: prvi atribut

print(feature['boja'])
#Alternatively, attributes can be referred to by index.
#This is a bit faster than using the name. For example, to get the second attribute:
print(feature[2])

#6.3.2. Iterating over selected features
#If you only need selected features
selection = layer.selectedFeatures()
for feature in selection:
    # do whatever you need with the feature
    pass
    
#6.3.3. Iterating over a subset of features 
#If you want to iterate over a given subset of features in a layer, such as those within a given are
areaOfInterest = QgsRectangle(450290,400520, 450750,400780)

request = QgsFeatureRequest().setFilterRect(areaOfInterest)

for feature in layer.getFeatures(request):
    # do whatever you need with the feature
    pass
request = QgsFeatureRequest().setFilterRect(areaOfInterest) \
    .setFlags(QgsFeatureRequest.ExactIntersect)
request = QgsFeatureRequest()
request.setLimit(2)
for feature in layer.getFeatures(request):
    print(feature)
# The expression will filter the features where the field "location_name"
# contains the word "Lake" (case insensitive)
exp = QgsExpression('location_name ILIKE \'%Lake%\'')
request = QgsFeatureRequest(exp)
# Only return selected fields to increase the "speed" of the request
request.setSubsetOfAttributes([0,2])

# More user friendly version
request.setSubsetOfAttributes(['boja','visina'],layer.fields())

# Don't return geometry objects to increase the "speed" of the request
request.setFlags(QgsFeatureRequest.NoGeometry)

# Fetch only the feature with id 1
request.setFilterFid(1)

# The options may be chained
request.setFilterRect(areaOfInterest).setFlags(QgsFeatureRequest.NoGeometry).setFilterFid(45).setSubsetOfAttributes([0,2])