# klasa QgsVectorLayerUtils
# sadrzi odredjene, korisne metode 
# priprema QgisFeature objekat da bude dodat lejeru
# zadrzavajuci sva ogranicenja i default vrednosti
# korisceni atribut building
broj = iface.activeLayer()
feat = QgsVectorLayerUtils.createFeature(broj)
# getValues metod omogucava dobijanje vrednosti za odredjeni atribut ili izraz
building.selectByIds([0])
value = QgsVectorLayerUtils.getValues(layer, 'unutar 250m objekti', selectedOnly=True)
print(value)