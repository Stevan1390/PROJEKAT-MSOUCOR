import os 

layers = QgsProject.instance().mapLayers()
print(layers)

l = [layer.name() for layer in QgsProject.instance().mapLayers().values()]
layers_list = {}
for l in QgsProject.instance().mapLayers().values():
  layers_list[l.name()] = l
  
print(layers_list)

import os 
root = QgsProject.instance().layerTreeRoot()
root.children()
child0 = root.children()[0]
print(child0)
ids = root.findLayerIds()
# access the first layer of the ids list
root.findLayer(ids[0])
root.findGroup('Klase ')
# list of all the checked layers in the TOC
checked_layers = root.checkedLayers()
print(checked_layers)