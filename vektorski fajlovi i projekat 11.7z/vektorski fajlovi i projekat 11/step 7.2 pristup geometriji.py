# kreiranje geometrije iz koordinata
gTacka = QgsGeometry.fromPointXY(QgsPointXY(7367975,4941647))
print(gTacka)
gLinija = QgsGeometry.fromPolyline([QgsPoint(7365894,4949697), QgsPoint(7369230,4935285)])
print(gLinija)
gPoligon = QgsGeometry.fromPolygonXY([
[QgsPointXY(7359602,4927949), 
QgsPointXY(7366506,4929147),
QgsPointXY(7364291.3,4924586.2)]
])
print(gPoligon)
# proverava tip geometrije
if gTacka.wkbType() == QgsWkbTypes.Point:
    print(gTacka.wkbType())
    # izlaz: 1 za tacku
if gLinija.wkbType() == QgsWkbTypes.LineString:
    print(gLinija.wkbType())
    # izlaz: 2 za liniju
if gPoligon.wkbType() == QgsWkbTypes.Polygon:
    print(gPoligon.wkbType())
    # izlaz: 3 za poligon

print('--------------------------------')

# alternativni nacin
print(QgsWkbTypes.displayString(gTacka.wkbType()))
# izlaz: Point
print(QgsWkbTypes.displayString(gLinija.wkbType()))
# izlaz: LineString
print(QgsWkbTypes.displayString(gPoligon.wkbType()))

print('--------------------------------')

# proverava da li je geometrija sastavljena iz vise delova ili ne
# vise o tome na https://sspinnovations.com/blog/lesser-known-gis-feature-types-multipoint-multipatch-dimension/
print(gTacka.isMultipart())

print('--------------------------------')

# metode za pristup svakom vektorskom tipu torke predstavljanje
# u vidu XY koordinata nisu prave torke vec QgsPoint objekti, cijim
# vrednostima se moze pristupiti pomocu x() i y() metodama
print(gTacka.asPoint())
print(gLinija.asPolyline())
print(gPoligon.asPolygon())
# za multipart geometrije to su: asMultiPoint(), asMultiPolyline(), asMultiPolygon()

print('--------------------------------')

# vrsi iteraciju  nad svim delovima geometrije
for deo in gPoligon.parts():
    print(deo.asWkt())

# vrsi transformaciju svakog dela geometrije
for deo in gTacka.parts():
    deo.transform(QgsCoordinateTransform(
    QgsCoordinateReferenceSystem('EPSG:6316'),
    QgsCoordinateReferenceSystem('EPSG:32634'),
    QgsProject.instance())
    )
print(gTacka.asWkt())