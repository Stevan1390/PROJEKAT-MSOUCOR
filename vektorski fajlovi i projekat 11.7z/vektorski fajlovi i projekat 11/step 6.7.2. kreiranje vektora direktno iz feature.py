# from qgis.PyQt5.QtCore import QVariant - ukoliko je standalone

# definise atribute za feature-e. Neophodno istancirati QgsFields()
atributi = QgsFields()
atributi.append(QgsField('prvi', QVariant.Int))
atributi.append(QgsField('drugi', QVariant.String))

# kreira instancu vektor file writer-a , koji ce kreirati vektorski fajl

# uzima koordinatni sistem projekta
crs = QgsProject.instance().crs()
transform_context = QgsProject().instance().transformContext()
save_options = QgsVectorFileWriter.SaveVectorOptions()
save_options.driverName = 'ESRI Shapefile'
save_options.fileEncoding = 'UTF-8'

writer = QgsVectorFileWriter.create(
"C:/Users/Stevan/Documents/vektorski fajlovi i projekat 11/proba_shp",
atributi,
QgsWkbTypes.Point,
crs,
transform_context,
save_options
)

if writer.hasError() != QgsVectorFileWriter.NoError:
    print('Greska priliom kreiranja fajla: ', writer.errorMessage())
    
# dodaje feature
feat = QgsFeature()

feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(391117,4842040)))
feat.setAttributes([4, 'materijal'])
writer.addFeature(feat)

# brise se writer kako bi se izbacili feature-i na disk
del writer

