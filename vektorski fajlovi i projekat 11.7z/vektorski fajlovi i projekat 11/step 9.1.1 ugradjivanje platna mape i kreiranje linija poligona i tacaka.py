
canvas = QgsMapCanvas()
canvas.show()

canvas.setCanvasColor(Qt.white)
canvas.enableAntiAliasing(True)

# korisceni lejer = CLC Cajetina
lejer = iface.activeLayer()

if not lejer.isValid():
    print('Lejer nije uspesno ucitan')

# namesta obim po ucitanom lejeru
canvas.setExtent(lejer.extent())

# podesava lejere za "platno" mape
canvas.setLayers([lejer])

linije = QgsRubberBand(canvas, False) # False oznacava da nije poligon
tacke = [
QgsPoint(7445776,4806044),
QgsPoint(7440796,4792240),
QgsPoint(7487188,4792525) 
]
linije.setToGeometry(QgsGeometry.fromPolyline(tacke), None)
linije.setWidth(3)
linije.setColor(QColor(255,255,255))

poligon = QgsRubberBand(canvas, True) # True oznacava da je u pitanju poligon
tacke = [
[QgsPointXY(7445776,4806044), 
QgsPointXY(7440796,4792240), 
QgsPointXY(7487188,4792525)]
]
poligon.setToGeometry(QgsGeometry.fromPolygonXY(tacke), None)
poligon.setColor(QColor(255,0,0))

# ukoliko zelimo da "sakrijemo" odredjeni item
#poligon.hide()

# ukoliko zelimo da prikazemo odredjeni item
#poligon.show()

# ukoliko zelimo da uklonimo lejer iz scene
#canvas.scene().removeItem(tacke)