import os
# i ucitavanjem odredjenih itema (razmernika, oznake za sever...)
projekat = QgsProject.instance()
layout = QgsPrintLayout(projekat)
# ukoliko kreiramo novi layout(dizajn) za stampanje, korisno je izvrsiti 
# inicijalizaciju default podesavanja, cime kreiramo prazan A4 list
layout.initializeDefaults()
layout.setName('Layout_py')
projekat.layoutManager().addLayout(layout)

# kreiranje mape
mapa = QgsLayoutItemMap(layout)
# Podesava poziciju i velicinu mape (default vrednosti su 
# 0 za sirinu i visinu i postavljena je na 0,0)
mapa.attemptMove(QgsLayoutPoint(5,10, QgsUnitTypes.LayoutMillimeters))
mapa.attemptResize(QgsLayoutSize(200, 160, QgsUnitTypes.LayoutMillimeters))
# Definise obim koji ce se renderovati
mapa.zoomToExtent(iface.mapCanvas().extent())
layout.addLayoutItem(mapa)

# kreiranje labela
label = QgsLayoutItemLabel(layout)
label.setText('Karta')
label.adjustSizeToText()
layout.addLayoutItem(label)

# kreiranje legende
legenda = QgsLayoutItemLegend(layout)
legenda.setLinkedMap(mapa) # instanca od QgsLayoutItemMap
layout.addLayoutItem(legenda)

# kreiranje razmernika
razmernik = QgsLayoutItemScaleBar(layout)
razmernik.setStyle('Double Box')
razmernik.setLinkedMap(mapa)
razmernik.applyDefaultSize()
layout.addLayoutItem(razmernik)

# kreiranje oznake za sever
strelica = QgsLayoutItemPicture(layout)
strelica.setPicturePath("/Users/Stevan/Documents/vektorski fajlovi i projekat/north_arrow.png")
layout.addLayoutItem(strelica)

label.attemptMove(QgsLayoutPoint(150,1.5, QgsUnitTypes.LayoutMillimeters))
legenda.attemptMove(QgsLayoutPoint(250, 5, QgsUnitTypes.LayoutMillimeters))
razmernik.attemptMove(QgsLayoutPoint(60, 190, QgsUnitTypes.LayoutMillimeters))


# ukoliko zelimo da exportujemo kartu u PDF formatu
#base_path = os.path.join(QgsProject.instance().homePath())
#pdf_path = os.path.join(base_path, 'izlaz.pdf')

#exporter = QgsLayoutExporter(layout)
#exporter.exportToPdf(pdf_path, QgsLayoutExporter.PdfExportSettings())