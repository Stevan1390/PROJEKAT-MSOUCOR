# 5.2 https://docs.qgis.org/3.16/en/docs/pyqgis_developer_cookbook/raster.html
#When a raster layer is loaded, it gets a default renderer based on its type.
# It can be altered either in the layer properties or programmatically.

import os # Ovo je potrebno i u  pyqgis konzoli

##putanja do tif /home/aleksandar/Projekti/QGis/GIS_1_ Vezba/P_1.tif
path_to_tif = "/Users/Stevan/Documents/vektorski fajlovi i projekat 11/B_1.tif"
rlayer = QgsRasterLayer(path_to_tif, "B_1.tif")
if not rlayer.isValid():
    print("Layer ne moze da se ucita!")
# dodavanje layer-a bez prikaza
QgsProject.instance().addMapLayer(rlayer, False)
# dobianja layer tree 
layerTree = iface.layerTreeCanvasBridge().rootGroup()
# position je broj od 0
layerTree.insertChildNode(-1, QgsLayerTreeLayer(rlayer))

#To query the current renderer:
print(rlayer.renderer())
print(rlayer.renderer().type())

#5.2.1. Single Band Rasters
fcn = QgsColorRampShader()
fcn.setColorRampType(QgsColorRampShader.Interpolated)
lista = [ QgsColorRampShader.ColorRampItem(0, QColor(0,255,0)),
      QgsColorRampShader.ColorRampItem(255, QColor(255,255,0)) ]
fcn.setColorRampItemList(lista)
shader = QgsRasterShader()
shader.setRasterShaderFunction(fcn)
#In the second step we will associate this shader with the raster layer:
renderer = QgsSingleBandPseudoColorRenderer(rlayer.dataProvider(), 1, shader)
rlayer.setRenderer(renderer)
rlayer.triggerRepaint()

