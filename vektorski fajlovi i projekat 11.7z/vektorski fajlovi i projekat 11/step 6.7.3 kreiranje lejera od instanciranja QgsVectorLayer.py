# from qgis.PyQt5.QtCore import import QVariant - ukoliko je standalone

# kreira se lejer 
layer = QgsVectorLayer('Point', 'vezbanje_tacke', 'memory')
priv = layer.dataProvider()

# dodavanje atributa
priv.addAttributes(
[QgsField('naziv', QVariant.String),
QgsField('br_st', QVariant.Int),
QgsField('rang', QVariant.Double)]
)

layer.updateFields() # obavestava vektorski lejer da azurira promene od provajdera

# dodavanje feature-a
feat = QgsFeature()
feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(7367413,4940679)))
feat.setAttributes(['Stil', 2500, 0.8])
priv.addFeatures([feat])

# azurira obim lejera kada su dodati novi feature (svojstva)
# posto se promena obima provajdera ne odrazava direktno na lejer
layer.updateExtents 

print('fields: ', len(priv.fields()))
print('features: ', priv.featureCount())
e = layer.extent()
print('obim: ', e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum())

# vrsi iteraciju (prolazak) kroz feature klase
features = layer.getFeatures()
for feat in features:
    print('F: ', feat.id(), feat.attributes(), feat.geometry().asPoint())