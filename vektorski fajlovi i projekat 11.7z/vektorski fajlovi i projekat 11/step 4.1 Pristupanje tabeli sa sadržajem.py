
# daje listu lejera pomocu komprhenzije liste
l = [layer.name() for layer in QgsProject.instance().mapLayers().values()]
# recnik sa key = nazivom lejera i value = objektom lejera
layers_list = {}
for l in QgsProject.instance().mapLayers().values():
  layers_list[l.name()] = l

print(layers_list)


