import os
path_to_B_1 ="/Users/Stevan/Documents/vektorski fajlovi i projekat/B_1.tif"
rlayer = QgsRasterLayer(path_to_B_1, "B_1.tif")
if not rlayer.isValid():
    print("Layer ne moze da se ucita!")
    
#rlayer = QgsProject.instance().mapLayersByName("srtm")[0]
rlayer = QgsProject.instance().mapLayersByName("B_1.tif")[0] # vodi racuna o nazivu layer-a
# get the resolution of the raster in layer unit
print(rlayer.width(), rlayer.height())

# vraca rezoluciju rastera
print(rlayer.extent())
#
print(rlayer.extent().toString())
# vraca x i y koordinate rastera kao stringove
print(rlayer.rasterType())
 # # vraca broj kanala od rastera (za multispektralne snimke bi bilo vise)
print(rlayer.bandCount())
# vraca naziv prvog spektralnog kanala od rastera
print(raster.bandName(1))
# vraca metapodatke od rastera kao QgsLayerMetadata objekat
print(raster.metadata())
